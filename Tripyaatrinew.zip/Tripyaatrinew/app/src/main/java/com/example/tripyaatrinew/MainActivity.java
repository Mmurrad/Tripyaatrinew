package com.example.tripyaatrinew;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText username,phonenumber;
    Button login,loginwithemail,loginwithfacebook,skip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.username_id);
        phonenumber=findViewById(R.id.phone_id);
        login=findViewById(R.id.login_id);
        loginwithemail=findViewById(R.id.facebooklogin_id);
        loginwithfacebook=findViewById(R.id.emaillogin_id);
        skip=findViewById(R.id.skip_id);


        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);
            }
        });

    }
}
